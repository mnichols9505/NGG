﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Number_Guessing_Game.Classes;

namespace Number_Guessing_Game
{
    class Program
    {
        static void Main(string[] args)
        {

            MainMenu mm = new MainMenu();
            mm.Menu();

        }

    }

}
